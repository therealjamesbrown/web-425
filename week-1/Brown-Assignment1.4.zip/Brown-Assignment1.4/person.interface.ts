/*
============================================
; Title:  Exercise 1.4
; Author: Professor Krasso
; Modified by: James Brown
; Date:   7/10/2020
; Description: exercise 1.4 per instructions
;===========================================
*/


export interface IPerson {
    firstName: string;
    lastName: string;
}